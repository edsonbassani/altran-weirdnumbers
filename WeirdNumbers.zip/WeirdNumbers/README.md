# altran-weirdnumbers
Weird Numbers Project
